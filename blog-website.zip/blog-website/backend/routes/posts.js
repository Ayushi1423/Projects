const express = require('express');
const router = express.Router();
const connection = require('../models/post');

// Get all posts
router.get('/', (req, res) => {
    connection.query('SELECT * FROM posts', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// Create a new post
router.post('/', (req, res) => {
    const { title, content } = req.body;
    connection.query('INSERT INTO posts (title, content) VALUES (?, ?)', [title, content], (err, results) => {
        if (err) throw err;
        res.json({ id: results.insertId, title, content });
    });
});

module.exports = router;
